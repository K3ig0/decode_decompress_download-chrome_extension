try {
    importScripts("background.js");
  } catch (e) {
    console.error(e);
  }